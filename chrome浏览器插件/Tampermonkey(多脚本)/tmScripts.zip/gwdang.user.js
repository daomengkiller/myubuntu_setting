// ==UserScript==
// @name        gwdang
// @name:zh-CN   购物党比价工具
// @namespace   no
// @description 京东.淘宝.天猫.易迅.亚马逊中国.一号店.苏宁易购.当当网.国美在线.新蛋网中国.拍拍网自动比价。不会被删的版本（大概
// @description:zh-CN 京东.淘宝.天猫.易迅.亚马逊中国.一号店.苏宁易购.当当网.国美在线.新蛋网中国.拍拍网自动比价。不会被删的版本（大概吧
// @include     http://*.jd.com/*
// @include     https://*.jd.com/*
// @include     http://*.taobao.com/*
// @include     https://*.taobao.com/*
// @include     http://*.tmall.com/*
// @include     https://*.tmall.com/*
// @include     http://*.yixun.com/*
// @include     http://*.51buy.com/*
// @include     http://*.amazon.cn/*
// @include     http://*.yhd.com/*
// @include     http://*.suning.com/*
// @include     http://*.dangdang.com/*
// @include     http://*.gome.com.cn/*
// @include     http://*.newegg.cn/*
// @include     http://*.paipai.com/*
// @include     https://*.amazon.com/*
// @include     http://www.kjt.com/*
// @include     http://www.kaola.com/*
// @include     http://www.tcl.com/*
// @include     http://shop.hisense.com/*
// @include     http://*.oppo.com/*
// @include     http://shop.vivo.com.cn/*
// @include     http://www.ebay.com/*
// @include     http://t.dianping.com/*
// @include     http://*.nuomi.com/*
// @include     http://*.meituan.com/*
// @include     https://yao.95095.com/*
// @include     http://*.feiniu.com/*
// @include     http://*.meilishuo.com/*
// @include     http://*.mogujie.com/*
// @include     http://shop.coolpad.cn/*
// @include     http://*.sephora.cn/*
// @include     http://*.yesmywine.com/*
// @include     http://*.yiguo.com/*
// @include     http://*.wanggou.com/*
// @include     http://mall.jia.com/*
// @include     http://weigou.baidu.com/*
// @include     http://*.mi.com/*
// @include     http://shop.letv.com/*
// @include     http://*.handu.com/*
// @include     http://*.taoshu.com/*
// @include     http://*.1688.com/*
// @include     http://*.muyingzhijia.com/*
// @include     http://*.vmall.com/*
// @include     http://*.xiji.com/*
// @include     http://*.xijie.com/*
// @version     1.2.1
// @grant 		none
// ==/UserScript==
(function(){
var s = document.createElement('script');s.setAttribute('src','https://greasyfork.org/scripts/14464-gwd/code/gwd.js?version=151418');document.body.appendChild(s);
})()